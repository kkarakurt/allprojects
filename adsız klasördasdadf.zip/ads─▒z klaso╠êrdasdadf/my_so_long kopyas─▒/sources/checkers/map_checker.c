/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_checker.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kkarakur <kkarakur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 10:39:06 by kkarakur          #+#    #+#             */
/*   Updated: 2023/10/22 14:43:51 by kkarakur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../libft/libft.h"
#include "checkers.h"
#include <stdlib.h>

/*
void	map_checker(char **argv, t_map *map)
{
	int		len;

	map->ber = argv[1];
	len = (int)ft_strlen(argv[1]) - 4;
	if (argv[1][len] != '.' || argv[1][len + 1] != 'b'
	|| argv[1][len + 2] != 'e' || argv[1][len + 3] != 'r' || len <= 0)
	{
		write (1, "Not ber file!\n", 15);
		exit(0);
	}
}
*/

void	map_checker(char **argv, t_map *map)
{
	int		i;

	i = ft_strlen(argv[1]);
	map->ber = argv[1];

	if (ft_strncmp(&(argv[1][i - 4]), ".ber\0", 5))
		write (1, "HATAA", 4);
}
