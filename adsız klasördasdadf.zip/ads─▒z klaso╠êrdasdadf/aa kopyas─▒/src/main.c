/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: buyilmaz <buyilmaz@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 17:02:04 by buyilmaz          #+#    #+#             */
/*   Updated: 2023/10/15 14:02:52 by buyilmaz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/philo.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <stdlib.h>

static int	create_philos(t_philo *philos)
{
	int	i;

	i = 0;
	while (i < philos->info->philo_nbr)
	{
		if (pthread_create(&philos[i].thread, NULL, &philo_routine, &philos[i]))
			return (1);
		i++;
	}
	return (0);
}

static void	init_philos(t_info *info, t_philo *philos)
{
	int	i;

	i = 0;
	while (i < info->philo_nbr)
	{
		philos[i].id = i + 1;
		philos[i].is_alive = true;
		philos[i].fed = false;
		philos[i].info = info;
		philos[i].last_meal = info->start_time;
		if (pthread_mutex_init(&philos[i].fork_r, NULL))
			return ;
		if (pthread_mutex_init(&philos[i].status_mutex, NULL))
			return ;
		if (pthread_mutex_init(&philos[i].eat_mutex, NULL))
			return ;
		if (pthread_mutex_init(&philos[i].fed_mutex, NULL))
			return ;
		philos[i].fork_l = &philos[(i + 1) % info->philo_nbr].fork_r;
		i++;
	}
}

static int	init_info(t_info *info, int argc, char **argv)
{
	info->philo_nbr = ft_atoi(argv[1]);
	info->die_time = ft_atoi(argv[2]);
	info->eat_time = ft_atoi(argv[3]);
	info->sleep_time = ft_atoi(argv[4]);
	info->meal_count = -1;
	if (argc == 6)
		info->meal_count = ft_atoi(argv[5]);
	if (info->philo_nbr == 0)
		return (write(2, "Error\n", 6), 0);
	if (pthread_mutex_init(&info->print_mutex, NULL))
		return (0);
	info->start_time = get_time();
	return (1);
}

static void	philo_alone(t_info *info)
{
	printf("%d %d %s\n", 0, 1, FORK);
	sensitive_usleep(info->die_time);
	printf("%lld %d %s\n", info->die_time + 1, 1, DIE);
}

int	main(int argc, char **argv)
{
	t_info		info;
	t_philo		*philos;
	pthread_t	monitor;

	if (check_args(argc, argv))
		return (1);
	if (init_info(&info, argc, argv) == 0)
		return (0);
	if (info.philo_nbr == 1)
	{
		philo_alone(&info);
		return (0);
	}
	philos = malloc(sizeof(t_philo) * info.philo_nbr);
	if (!philos)
		return (1);
	init_philos(&info, philos);
	if (pthread_create(&monitor, NULL, &monitor_routine, philos))
		return (1);
	if (create_philos(philos))
		return (1);
	clean_up(&monitor, philos);
	return (0);
}
