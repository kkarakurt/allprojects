/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: buyilmaz <buyilmaz@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 17:08:57 by buyilmaz          #+#    #+#             */
/*   Updated: 2023/10/15 13:47:31 by buyilmaz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/philo.h"
#include <sys/time.h>
#include <stdlib.h>
#include <unistd.h>

void	clean_up(pthread_t *monitor, t_philo *philos)
{
	int	i;

	pthread_join(*monitor, NULL);
	i = 0;
	while (i < philos->info->philo_nbr)
	{
		pthread_join(philos[i].thread, NULL);
		i++;
	}
	i = 0;
	while (i < philos->info->philo_nbr)
	{
		pthread_mutex_destroy(&philos[i].fork_r);
		pthread_mutex_destroy(&philos[i].status_mutex);
		pthread_mutex_destroy(&philos[i].eat_mutex);
		pthread_mutex_destroy(&philos[i].fed_mutex);
		i++;
	}
	pthread_mutex_destroy(&philos[0].info->print_mutex);
	free(philos);
}

int	ft_atoi(const char *str)
{
	int	num;
	int	i;

	i = 0;
	num = 0;
	while (str[i])
	{
		num = num * 10 + (str[i] - '0');
		i++;
	}
	return (num);
}

int	check_args(int argc, char **argv)
{
	int	i;
	int	j;

	if (argc < 5 || argc > 6)
	{
		return (write(2, "Error: wrong number of arguments\n", 35), 1);
	}
	j = 1;
	while (argv[j])
	{
		i = 0;
		while (argv[j][i])
		{
			if (argv[j][i] < '0' || argv[j][i] > '9')
			{
				return (write(2, "Error:Parameters must be positive\n", 35), 1);
			}
			i++;
		}
		j++;
	}
	return (0);
}

t_ms	get_time(void)
{
	struct timeval	time;

	gettimeofday(&time, NULL);
	return ((time.tv_usec / 1000 + time.tv_sec * 1000));
}

void	sensitive_usleep(t_ms time)
{
	t_ms	wake_up;

	wake_up = get_time() + time;
	while (get_time() < wake_up)
		usleep(200);
}
